<h4 align="center">
 
![sapo](https://user-images.githubusercontent.com/99045923/174337044-54091980-0c72-4725-b91e-7516c2c84c62.gif)



<hr>

</h4>

<h3 align="center">
  
Olá, eu sou o Lucas! <br>
![bandeira](https://img.shields.io/badge/-BR-1fad1a)
 
<h4>

```
Estudante de Engenharia de Software pela Unicesumar - EAD, 
sou fascinado por computação desde criança e atualmente tenho me dedicado a me tornar um dev front-end.
```
</h4>
  
## Atualmente estudando 📚

  - JavaScript
  
## Habilidades 💻
  
<div style="display: inline_block">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/c/c-original.svg" alt="C" width="40" height="40">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg" alt="C++" width="40" height="40">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" alt="HTML5" width="40" height="40">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" alt="CSS3" width="40" height="40">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" alt="JAVA" width="40" height="40">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" alt="JAVASCRIPT" width="40" height="40">
</div>

## Meus dados no Github

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=3lucasrs&show_icons=true&theme=tokyonight)
[![arthurspk](https://github-readme-stats.vercel.app/api/top-langs/?username=3lucasrs&hide=html&layout=compact=true&theme=tokyonight)](https://github.com/3lucasrs/)
<!-- ![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=arthurspk&layout=compact&theme=tokyonight) -->
![Snake animation](https://github.com/rafaballerini/rafaballerini/blob/output/github-contribution-grid-snake.svg)

